<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
    <a href="logout.php">Logout</a></p>
        <div class="dashboard">
            <header>
                <h2>Namoc's Dashboard</h2>
                <div class="overview">
                    <div class="card">
                        <h3>Savings:</h3>
                        <p>PHP 500.00</p>
                    </div>

                    <div class="card">
                        <h3>Expenses</h3>
                        <p>January 30, 2025</p>
                    </div>

                    <div class="card">
                        <h3>Books:</h3>
                        <p>PHP 120.00</p>
                        <h3>Food:</h3>
                        <p>PHP 300.00</p>
                        <p>__________</p>
                        <p>Php420.00</p>
                        
 </div>    
                    
                    <div class="card">
                        <h3>Remaining Balance:</h3>
                        <p>PHP 80.00</p>
                    </div>
                </div>
            </header>
        </div>
    </div>
</body>
</html>
